MAP Decoding Of "Eureka!" Experimental Data

- Decoding of E1-E4 draws source data from files: 
  E1_2and3run.sort.uniq
  E2_2and3run.sort.uniq
  E3_2and3run.sort.uniq
  E4_2and3run.sort.uniq

- For x = 1, 2, 3, 4
- For y = 1, 2, 3, 4, 5
  Ex-map-decoding-read-threshold-y.txt 
  Contains MAP decoding results for decoding template sequence Ex 
  given reads sampled from file Ex_2and3run.sort.uniq.   
  For MAP decoding, up to 10 longest strands are used, where each
  strand must have a coverage greater than or equal to y. 

- For x = 1, 2, 3, 4
- For y = 1, 2, 3, 4, 5
  Ex-best-map-decoding.txt 
  Contains the best decoding results for a given number of reads,
  taken from all of Ex-map-decoding-read-threshold-y.txt.  
   
- For x = 1, 2, 3, 4
  Ex-plain-filter-decoding.txt
  Contains plain filter decoding results. The strand with the  
  highest read coverage and correct length of 16 nucleotides, 
  is the output of this baseline decoding. 


FILE FORMATS
- For x = 1, 2, 3, 4
- For y = 1, 2, 3, 4, 5
  Ex-map-decoding-read-threshold-y.txt 
A B C 
A = Number of reads sampled randomly with replacement.
B = Number of correct MAP decodings for template sequence x, out of 500 decodings.  
C = Internal diagnostic number not used. 
    Total errors up to a maximum of 16 nucleotides * 500 = 8000. 



- For x = 1, 2, 3, 4
- For y = 1, 2, 3, 4, 5
  Ex-best-map-decoding.txt 
A B C 
A = Number of reads sampled randomly with replacement.
B = Number of correct MAP decodings for template sequence x, out of 500 decodings. 
    This number is the best decoding result from all Ex-map-decoding-read-threshold-y.txt.  
C = The threshold which provided the best decoding result.  



- For x = 1, 2, 3, 4
- For y = 1, 2, 3, 4, 5
  Ex-plain-filter-decoding.txt 
A B C
A = Number of reads sampled randomly with replacement.
B = Number of correct plain filter decodings for template sequence x, out of 1000 decodings.
C = Internal diagnostic number not used. 
    Total errors up to a maximum of 16 nucleotides * 1000 = 16000.  


