"Eureka!" Experimental DNA Sequencing Data 

Contains: 
- Sequencing Reads for E1-E4. 
- DNA strands were length-purified in silico.   
- DNA strands are sorted in order of highest read coverage. 


FILES: 
- x = 1, 2, 3, 4
- Ex_2and3run.sort


FILE FORMAT: 
  61 CATATCACATCTC
  55 CATATCATCTC
  41 CATATCTCTC
  41 CATATCACTCTC
  36 CATATCTCTCACTC
  ...

Each row contains the read coverage of the DNA strand 
that was sequenced, followed by the nucleotide sequence 
of the strand.